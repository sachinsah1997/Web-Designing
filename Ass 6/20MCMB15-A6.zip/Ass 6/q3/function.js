$(document).ready(function() {

    $("#date").datepicker();
    $("#selectable").selectable();
    $("#sortable").sortable();
    $("#sortable").disableSelection();
    $(document).tooltip()
});
